"use client"

import { useEffect, useRef } from "react"

/**
 * VisitorTracker — невидимый компонент, собирает данные о посетителе
 * и отправляет на /api/analytics при загрузке страницы.
 *
 * Запускается один раз при монтировании.
 * Использует localStorage для постоянного visitorId (а не sessionId),
 * чтобы один и тот же браузер не плодил дубли при перезагрузках.
 */

/** Ключ для localStorage — постоянный ID посетителя */
const VISITOR_ID_KEY = "nastolka-visitor-id"

/** Минимальный интервал между отправками (мс) — чтобы не спамить при быстрых перезагрузках */
const MIN_INTERVAL_MS = 30 * 1000 // 30 секунд

export function VisitorTracker() {
  const sentRef = useRef(false)
  useEffect(() => {
    if (sentRef.current) return
    sentRef.current = true

    // Проверяем, не отправляли ли недавно (защита от дублирования при перезагрузках)
    try {
      const lastSent = localStorage.getItem("nastolka-analytics-last-sent")
      const now = Date.now()
      if (lastSent && now - parseInt(lastSent) < MIN_INTERVAL_MS) {
        // Отправляли менее 30 секунд назад — пропускаем
        return
      }
      localStorage.setItem("nastolka-analytics-last-sent", String(now))
    } catch {
      // localStorage недоступен — отправляем в любом случае
    }

    const nav = navigator
    const scr = screen
    const data = {
      screenResolution: `${scr.width}x${scr.height}`,
      viewportSize: `${window.innerWidth}x${window.innerHeight}`,
      pixelRatio: window.devicePixelRatio,
      colorDepth: scr.colorDepth,
      cookiesEnabled: nav.cookieEnabled,
      onlineStatus: nav.onLine,
      language: nav.language,
      languages: (nav as any).languages ? (nav as any).languages.join(",") : nav.language,
      platform: (nav as any).platform || "unknown",
      touchSupport: "ontouchstart" in window,
      maxTouchPoints: (nav as any).maxTouchPoints || 0,
      connectionType: (nav as any).connection?.effectiveType ||
                      (nav as any).connection?.type || "unknown",
      sessionId: getVisitorId(), // ← постоянный ID (localStorage), не sessionStorage
      pageUrl: window.location.href,
      pagePath: window.location.pathname,
    }

    try {
      const blob = new Blob([JSON.stringify(data)], { type: "application/json" })
      if (nav.sendBeacon) {
        nav.sendBeacon("/api/analytics", blob)
      } else {
        fetch("/api/analytics", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(data),
          keepalive: true,
        }).catch(() => {})
      }
    } catch {
      // silently fail
    }
  }, [])

  return null
}

/**
 * Постоянный visitor ID — хранится в localStorage (а НЕ sessionStorage).
 * Один ID на весь браузер, не зависит от вкладок/сессий.
 * Используется для дедупликации: один посетитель = одна запись на страницу.
 */
function getVisitorId(): string {
  try {
    let id = localStorage.getItem(VISITOR_ID_KEY)
    if (!id) {
      id = `v-${Date.now()}-${Math.random().toString(36).slice(2, 11)}`
      localStorage.setItem(VISITOR_ID_KEY, id)
    }
    return id
  } catch {
    return "unknown"
  }
}
