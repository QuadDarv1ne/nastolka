// WebSocket сервер для синхронизации состояния игры "Настолка" между устройствами.
// v61: Device Registry — каждое устройство = отдельная команда (автоприсвоение).
import { createServer } from 'http'
import { Server } from 'socket.io'

const httpServer = createServer()
const io = new Server(httpServer, {
  path: '/',
  cors: { origin: '*', methods: ['GET', 'POST'] },
  pingTimeout: 60000,
  pingInterval: 25000,
})

// ═══════════════ Структуры данных ═══════════════

interface DeviceInfo {
  /** Уникальный ID устройства (генерируется клиентом, хранится в localStorage) */
  deviceId: string
  /** Тип устройства: phone, tablet, laptop, desktop */
  deviceType: string
  /** ОС */
  os: string
  /** Браузер */
  browser: string
  /** Разрешение экрана */
  screenResolution: string
  /** User-Agent */
  userAgent: string
  /** Язык */
  language: string
  /** Имя, которое ввёл пользователь (опционально) */
  playerName?: string
  /** socket.id текущего подключения */
  socketId: string
  /** Время подключения */
  connectedAt: number
}

interface RoomInfo {
  code: string
  members: Set<string>
  /** Маппинг socketId → DeviceInfo */
  devices: Map<string, DeviceInfo>
  /** Маппинг deviceId → teamIdx (какое устройство за какую команду) */
  teamAssignments: Map<string, number>
  hostName?: string
  teamCount?: number
  targetScore?: number
  isOpen?: boolean
  createdAt: number
}

const rooms = new Map<string, RoomInfo>()
const socketToRoom = new Map<string, string>()
const lobbyWatchers = new Set<string>()

const ALPHABET = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'
const generateRoomCode = () => {
  let code = ''
  for (let i = 0; i < 4; i++) code += ALPHABET[Math.floor(Math.random() * ALPHABET.length)]
  return rooms.has(code) ? generateRoomCode() : code
}

// ═══════════════ Broadcast списка лобби ═══════════════

function getOpenLobbies() {
  const list: Array<{
    code: string; members: number; maxMembers: number
    hostName: string; teamCount: number; targetScore: number
    devices: Array<{ deviceId: string; deviceType: string; playerName: string }>
  }> = []
  for (const [code, room] of rooms) {
    if (room.isOpen && room.members.size > 0) {
      const devices: Array<{ deviceId: string; deviceType: string; playerName: string }> = []
      for (const [, info] of room.devices) {
        devices.push({ deviceId: info.deviceId, deviceType: info.deviceType, playerName: info.playerName || '???' })
      }
      list.push({
        code, members: room.members.size, maxMembers: 4,
        hostName: room.hostName || '???', teamCount: room.teamCount || 2,
        targetScore: room.targetScore || 10, devices,
      })
    }
  }
  return list.sort((a, b) => b.members - a.members)
}

function broadcastLobbyList() {
  const list = getOpenLobbies()
  for (const socketId of lobbyWatchers) {
    io.to(socketId).emit('lobby-list-update', { lobbies: list })
  }
}

// ═══════════════ Авто-присвоение команды устройству ═══════════════

function assignTeamToDevice(room: RoomInfo, deviceId: string): number {
  // Если уже назначен — возвращаем
  const existing = room.teamAssignments.get(deviceId)
  if (existing !== undefined) return existing

  // Находим первую свободную команду
  const assigned = new Set(room.teamAssignments.values())
  const maxTeams = room.teamCount || 2
  for (let i = 0; i < maxTeams; i++) {
    if (!assigned.has(i)) {
      room.teamAssignments.set(deviceId, i)
      return i
    }
  }
  // Все заняты — spectator (-1)
  return -1
}

// ═══════════════ Broadcast devices + team assignments в комнату ═══════════════

function broadcastRoomInfo(roomCode: string) {
  const room = rooms.get(roomCode)
  if (!room) return
  const devices: Array<{
    deviceId: string; deviceType: string; os: string; browser: string
    screenResolution: string; language: string; playerName: string
    teamIdx: number; socketId: string
  }> = []
  for (const [socketId, info] of room.devices) {
    const teamIdx = room.teamAssignments.get(info.deviceId) ?? -1
    devices.push({
      deviceId: info.deviceId, deviceType: info.deviceType, os: info.os,
      browser: info.browser, screenResolution: info.screenResolution,
      language: info.language, playerName: info.playerName || '???',
      teamIdx, socketId,
    })
  }
  io.to(roomCode).emit('room-devices', { devices, members: room.members.size })
}

// ═══════════════ Обработка подключений ═══════════════

io.on('connection', (socket) => {
  // ── Создать комнату с device info ──
  socket.on('create-room', (data: {
    open?: boolean; hostName?: string; teamCount?: number; targetScore?: number
    device?: Partial<DeviceInfo>
  }) => {
    const code = generateRoomCode()
    const deviceInfo: DeviceInfo = {
      deviceId: data.device?.deviceId || `dev-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
      deviceType: data.device?.deviceType || 'unknown',
      os: data.device?.os || 'unknown',
      browser: data.device?.browser || 'unknown',
      screenResolution: data.device?.screenResolution || 'unknown',
      userAgent: data.device?.userAgent || '',
      language: data.device?.language || 'unknown',
      playerName: data.device?.playerName || data.hostName || '???',
      socketId: socket.id,
      connectedAt: Date.now(),
    }

    rooms.set(code, {
      code,
      members: new Set([socket.id]),
      devices: new Map([[socket.id, deviceInfo]]),
      teamAssignments: new Map([[deviceInfo.deviceId, 0]]), // Хост = команда 0
      hostName: data?.hostName || deviceInfo.playerName,
      teamCount: data?.teamCount || 2,
      targetScore: data?.targetScore || 10,
      isOpen: data?.open ?? false,
      createdAt: Date.now(),
    })
    socketToRoom.set(socket.id, code)
    socket.join(code)

    // Отправляем хосту: код комнаты + team assignment + список устройств
    socket.emit('room-created', { code })
    socket.emit('team-assigned', { teamIdx: 0, deviceId: deviceInfo.deviceId })
    broadcastRoomInfo(code)

    if (data?.open) broadcastLobbyList()
  })

  // ── Подписаться на список открытых лобби ──
  socket.on('watch-lobbies', () => {
    lobbyWatchers.add(socket.id)
    socket.emit('lobby-list-update', { lobbies: getOpenLobbies() })
  })

  socket.on('unwatch-lobbies', () => { lobbyWatchers.delete(socket.id) })

  // ── Присоединиться к комнате с device info ──
  socket.on('join-room', (data: { code: string; device?: Partial<DeviceInfo> }) => {
    const upper = (data.code || '').toUpperCase().trim()
    const room = rooms.get(upper)
    if (!room) { socket.emit('room-error', { message: 'Room not found' }); return }
    if (room.members.size >= 4) { socket.emit('room-error', { message: 'Room full' }); return }

    const deviceInfo: DeviceInfo = {
      deviceId: data.device?.deviceId || `dev-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
      deviceType: data.device?.deviceType || 'unknown',
      os: data.device?.os || 'unknown',
      browser: data.device?.browser || 'unknown',
      screenResolution: data.device?.screenResolution || 'unknown',
      userAgent: data.device?.userAgent || '',
      language: data.device?.language || 'unknown',
      playerName: data.device?.playerName || '???',
      socketId: socket.id,
      connectedAt: Date.now(),
    }

    room.members.add(socket.id)
    room.devices.set(socket.id, deviceInfo)
    socketToRoom.set(socket.id, upper)
    socket.join(upper)

    // ── Авто-присвоение команды ──
    const teamIdx = assignTeamToDevice(room, deviceInfo.deviceId)

    // Отправляем гостю: код комнаты + team assignment + список устройств
    socket.emit('room-joined', { code: upper, members: room.members.size })
    socket.emit('team-assigned', { teamIdx, deviceId: deviceInfo.deviceId })

    // Уведомляем остальных о новом устройстве
    socket.to(upper).emit('peer-joined', { id: socket.id, members: room.members.size })
    broadcastRoomInfo(upper)
    broadcastLobbyList()
  })

  // ── Обновить имя игрока ──
  socket.on('update-player-name', (data: { playerName: string }) => {
    const roomCode = socketToRoom.get(socket.id)
    if (!roomCode) return
    const room = rooms.get(roomCode)
    if (!room) return
    const info = room.devices.get(socket.id)
    if (info) {
      info.playerName = data.playerName.slice(0, 20)
      broadcastRoomInfo(roomCode)
    }
  })

  // ── Синхронизация состояния игры ──
  socket.on('state-update', ({ state }: { state: unknown }) => {
    const room = socketToRoom.get(socket.id)
    if (room) socket.to(room).emit('state-update', { from: socket.id, state })
  })

  socket.on('request-state', () => {
    const room = socketToRoom.get(socket.id)
    if (room) socket.to(room).emit('state-requested', { from: socket.id })
  })

  socket.on('send-state-to', ({ to, state }: { to: string; state: unknown }) => {
    io.to(to).emit('state-update', { from: socket.id, state })
  })

  socket.on('meta-update', ({ meta }: { meta: unknown }) => {
    const room = socketToRoom.get(socket.id)
    if (room) socket.to(room).emit('meta-update', { from: socket.id, meta })
  })

  socket.on('update-room-meta', (data: { teamCount?: number; targetScore?: number; open?: boolean }) => {
    const roomCode = socketToRoom.get(socket.id)
    if (!roomCode) return
    const room = rooms.get(roomCode)
    if (!room) return
    const isFirst = room.members.values().next().value === socket.id
    if (!isFirst) return
    if (data.teamCount !== undefined) room.teamCount = data.teamCount
    if (data.targetScore !== undefined) room.targetScore = data.targetScore
    if (data.open !== undefined) room.isOpen = data.open
    broadcastLobbyList()
  })

  socket.on('ping-test', () => { socket.emit('pong-test', { time: Date.now() }) })

  // ── Отключение ──
  socket.on('disconnect', () => {
    const roomCode = socketToRoom.get(socket.id)
    if (roomCode) {
      const room = rooms.get(roomCode)
      if (room) {
        room.members.delete(socket.id)
        room.devices.delete(socket.id)
        if (room.members.size === 0) {
          rooms.delete(roomCode)
        } else {
          socket.to(roomCode).emit('peer-left', { id: socket.id, members: room.members.size })
          broadcastRoomInfo(roomCode)
        }
      }
      broadcastLobbyList()
    }
    lobbyWatchers.delete(socket.id)
    socketToRoom.delete(socket.id)
  })
})

httpServer.listen(3003, '0.0.0.0', () => {
  console.log('Nastolka WebSocket server on port 3003 (0.0.0.0) — v61 Device Registry')
})

process.on('SIGTERM', () => httpServer.close(() => process.exit(0)))
process.on('SIGINT', () => httpServer.close(() => process.exit(0)))
